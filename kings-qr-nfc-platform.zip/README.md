# Kings & Son's QR + NFC Platform — Setup (5 steps)

1. **Supabase**: create/choose a project → SQL Editor → paste `setup.sql` → Run.
2. **Admin user**: Supabase → Authentication → Users → Add user (your email + password). Only this login opens `admin.html`.
3. **Keys**: Project Settings → API → copy URL + anon key into `config.js`.
4. **Deploy**: drag this whole folder to Netlify.
5. **Use**:
   - `admin.html` → Add client business → fill links, set client PIN → QR / NFC appears.
   - Give client: `client.html` + their business code + PIN.
   - Customers scan QR / tap NFC → `card.html?b=<code>`.

Security: client PIN can only change layout, order, visibility and button names. Links & UPI are admin-only. Use 6-digit PINs.
