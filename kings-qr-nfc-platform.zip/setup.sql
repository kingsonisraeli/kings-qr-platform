-- Kings & Son's QR + NFC Platform — run once in Supabase SQL Editor
create extension if not exists pgcrypto;

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  tagline text default 'Everything you need, in one place.',
  logo_url text,
  accent text default '#16a34a',
  layout text not null default 'grid' check (layout in ('grid','list')),
  buttons jsonb not null default '[
    {"key":"menu","label":"Digital Menu","sub":"View products & prices","value":"","visible":true},
    {"key":"website","label":"Website","sub":"Visit business site","value":"","visible":true},
    {"key":"reviews","label":"Google Reviews","sub":"Rate your experience","value":"","visible":true},
    {"key":"payment","label":"Payment","sub":"Pay using UPI","value":"","visible":true},
    {"key":"instagram","label":"Instagram","sub":"Follow our page","value":"","visible":true},
    {"key":"facebook","label":"Facebook","sub":"Connect with us","value":"","visible":true},
    {"key":"whatsapp","label":"WhatsApp","sub":"Chat, enquire or place an order","value":"","visible":true}
  ]'::jsonb,
  client_pin_hash text,
  active boolean not null default true,
  scans integer not null default 0,
  created_at timestamptz not null default now()
);

alter table public.businesses enable row level security;

-- Admin (logged-in Supabase Auth user) has full access. Anonymous visitors have NO direct table access.
drop policy if exists "admin all" on public.businesses;
create policy "admin all" on public.businesses
  for all to authenticated using (true) with check (true);

create or replace function public.card_json(b public.businesses) returns jsonb
language sql immutable as $$
  select jsonb_build_object('slug',b.slug,'name',b.name,'tagline',b.tagline,
    'logo_url',b.logo_url,'accent',b.accent,'layout',b.layout,'buttons',b.buttons);
$$;

-- Public card (QR / NFC page)
create or replace function public.get_card(p_slug text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare b public.businesses;
begin
  select * into b from public.businesses where slug = p_slug and active;
  if not found then return null; end if;
  update public.businesses set scans = scans + 1 where id = b.id;
  return public.card_json(b);
end $$;

-- Client login (slug + PIN)
create or replace function public.client_login(p_slug text, p_pin text) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare b public.businesses;
begin
  select * into b from public.businesses
   where slug = p_slug and active and client_pin_hash is not null
     and client_pin_hash = crypt(p_pin, client_pin_hash);
  if not found then return null; end if;
  return public.card_json(b);
end $$;

-- Client can ONLY change: layout, order, visibility, button names. Links/payment stay admin-controlled.
create or replace function public.client_save(p_slug text, p_pin text, p_layout text, p_order jsonb) returns jsonb
language plpgsql security definer set search_path = public, extensions as $$
declare b public.businesses; res jsonb;
begin
  select * into b from public.businesses
   where slug = p_slug and active and client_pin_hash is not null
     and client_pin_hash = crypt(p_pin, client_pin_hash);
  if not found then raise exception 'Invalid PIN'; end if;

  select jsonb_agg(jsonb_build_object(
           'key', o.item->>'key',
           'label', left(coalesce(nullif(trim(e.item->>'label'),''), o.item->>'label'), 30),
           'sub', o.item->>'sub',
           'value', o.item->>'value',
           'visible', coalesce((e.item->>'visible')::boolean, true)) order by e.ord)
    into res
    from jsonb_array_elements(p_order) with ordinality as e(item, ord)
    join jsonb_array_elements(b.buttons) as o(item) on o.item->>'key' = e.item->>'key';

  update public.businesses
     set layout = case when p_layout in ('grid','list') then p_layout else layout end,
         buttons = coalesce(res, buttons)
   where id = b.id
   returning * into b;
  return public.card_json(b);
end $$;

-- Admin sets / resets a client's PIN
create or replace function public.admin_set_pin(p_id uuid, p_pin text) returns void
language plpgsql security definer set search_path = public, extensions as $$
begin
  if auth.uid() is null then raise exception 'Not allowed'; end if;
  update public.businesses set client_pin_hash = crypt(p_pin, gen_salt('bf')) where id = p_id;
end $$;

revoke all on function public.get_card(text), public.client_login(text,text),
  public.client_save(text,text,text,jsonb), public.admin_set_pin(uuid,text) from public;
grant execute on function public.get_card(text), public.client_login(text,text),
  public.client_save(text,text,text,jsonb) to anon, authenticated;
grant execute on function public.admin_set_pin(uuid,text) to authenticated;
